//
// Created by Vanessa on 27/09/2025.
//

#ifndef ERASMOONICHAN_UTILS_H
#define ERASMOONICHAN_UTILS_H
#include <fstream>
#include <iomanip>
#include <iostream>
#define MAX_ARTISTAS 14
#define MAX_CANCIONES 40
#define MAX_REPRODUCCIONES 40
using namespace std;
#endif //ERASMOONICHAN_UTILS_H